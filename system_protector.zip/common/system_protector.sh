#!/system/bin/sh

MODDIR=${0%/*}
NOTIFY="/data/adb/modules/system_protector/ksu_notify"
CONFIG="/data/adb/system_protector/config"
BACKUP_DIR="/data/adb/system_protector/backups"

# 加载配置
[ -f "$CONFIG" ] && . "$CONFIG"

# 切换备份模式
switch_mode() {
  if [ "$BACKUP_MODE" = "boot" ]; then
    new_mode="periodic"
  else
    new_mode="boot"
  fi
  
  sed -i "s/BACKUP_MODE=.*/BACKUP_MODE=$new_mode/" "$CONFIG"
  
  # 重启服务
  pkill -f "service.sh"
  nohup "$MODDIR/service.sh" >/dev/null 2>&1 &
  
  $NOTIFY "已切换到${new_mode}备份模式"
  echo "✅ 备份模式已切换为: $new_mode"
}

# 手动备份
manual_backup() {
  $NOTIFY "正在启动手动系统备份..."
  
  # 调用备份函数
  "$MODDIR/service.sh" backup_system
  
  $NOTIFY "手动备份已完成"
}

# 查看备份
list_backups() {
  echo -e "\n系统备份列表:"
  ls -lt "$BACKUP_DIR"/*.tgz 2>/dev/null || echo "暂无备份"
  
  read -p "输入回车返回主菜单..."
}

# 主菜单
show_menu() {
  while true; do
    echo -e "\n===== 系统保护管理菜单 ====="
    echo "当前模式: $BACKUP_MODE"
    echo "1. 切换备份模式"
    echo "2. 立即备份系统"
    echo "3. 查看备份列表"
    echo "4. 设置备份延迟"
    echo "5. 退出"
    echo "============================"
    read -p "请选择操作 [1-5]: " choice
    
    case $choice in
      1) switch_mode ;;
      2) manual_backup ;;
      3) list_backups ;;
      4)
        current_delay=${BACKUP_DELAY:-30}
        echo "当前备份延迟: ${current_delay}秒"
        read -p "请输入新延迟(秒): " new_delay
        
        if [[ "$new_delay" =~ ^[0-9]+$ ]] && [ "$new_delay" -ge 5 ]; then
          sed -i "s/BACKUP_DELAY=.*/BACKUP_DELAY=$new_delay/" "$CONFIG"
          $NOTIFY "启动延迟设置为${new_delay}秒"
          echo "✅ 启动延迟已设置为: ${new_delay}秒"
        else
          echo "错误: 请输入大于5的整数"
        fi
        ;;
      5) exit 0 ;;
      *) echo "无效选择" ;;
    esac
  done
}

show_menu