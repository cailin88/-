#!/system/bin/sh

MODDIR=${0%/*}

# 创建备份目录
mkdir -p /data/adb/system_protector/backups
mkdir -p /data/adb/system_protector/locks

# 安装通知工具
cp -f $MODDIR/system/bin/ksu_notify /data/adb/modules/system_protector/
chmod 755 /data/adb/modules/system_protector/ksu_notify

# 加载配置
CONFIG="/data/adb/system_protector/config"
[ -f "$CONFIG" ] && . "$CONFIG"

# 如果是启动模式，创建备份锁
if [ "$BACKUP_MODE" = "boot" ]; then
  touch /data/adb/system_protector/locks/boot_backup.lock
fi